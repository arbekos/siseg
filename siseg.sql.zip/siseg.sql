-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 16-11-2012 a las 20:47:13
-- Versión del servidor: 5.5.8
-- Versión de PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `siseg`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_group`
--

CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `auth_group`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_group_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_425ae3c4` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `auth_group_permissions`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_permission`
--

CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_1bb8f392` (`content_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Volcar la base de datos para la tabla `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add permission', 1, 'add_permission'),
(2, 'Can change permission', 1, 'change_permission'),
(3, 'Can delete permission', 1, 'delete_permission'),
(4, 'Can add group', 2, 'add_group'),
(5, 'Can change group', 2, 'change_group'),
(6, 'Can delete group', 2, 'delete_group'),
(7, 'Can add user', 3, 'add_user'),
(8, 'Can change user', 3, 'change_user'),
(9, 'Can delete user', 3, 'delete_user'),
(10, 'Can add content type', 4, 'add_contenttype'),
(11, 'Can change content type', 4, 'change_contenttype'),
(12, 'Can delete content type', 4, 'delete_contenttype'),
(13, 'Can add session', 5, 'add_session'),
(14, 'Can change session', 5, 'change_session'),
(15, 'Can delete session', 5, 'delete_session'),
(16, 'Can add site', 6, 'add_site'),
(17, 'Can change site', 6, 'change_site'),
(18, 'Can delete site', 6, 'delete_site'),
(19, 'Can add log entry', 7, 'add_logentry'),
(20, 'Can change log entry', 7, 'change_logentry'),
(21, 'Can delete log entry', 7, 'delete_logentry'),
(22, 'Can add tema', 8, 'add_tema'),
(23, 'Can change tema', 8, 'change_tema'),
(24, 'Can delete tema', 8, 'delete_tema'),
(25, 'Can add subtema', 9, 'add_subtema'),
(26, 'Can change subtema', 9, 'change_subtema'),
(27, 'Can delete subtema', 9, 'delete_subtema'),
(28, 'Can add estructura_general', 10, 'add_estructura_general'),
(29, 'Can change estructura_general', 10, 'change_estructura_general'),
(30, 'Can delete estructura_general', 10, 'delete_estructura_general'),
(31, 'Can add sistema', 11, 'add_sistema'),
(32, 'Can change sistema', 11, 'change_sistema'),
(33, 'Can delete sistema', 11, 'delete_sistema'),
(34, 'Can add indicador', 12, 'add_indicador'),
(35, 'Can change indicador', 12, 'change_indicador'),
(36, 'Can delete indicador', 12, 'delete_indicador'),
(37, 'Can add categoria_indicador', 13, 'add_categoria_indicador'),
(38, 'Can change categoria_indicador', 13, 'change_categoria_indicador'),
(39, 'Can delete categoria_indicador', 13, 'delete_categoria_indicador'),
(40, 'Can add user profile', 14, 'add_userprofile'),
(41, 'Can change user profile', 14, 'change_userprofile'),
(42, 'Can delete user profile', 14, 'delete_userprofile'),
(46, 'Can add indicador568', 16, 'add_indicador568'),
(47, 'Can change indicador568', 16, 'change_indicador568'),
(48, 'Can delete indicador568', 16, 'delete_indicador568');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_user`
--

CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `auth_user`
--

INSERT INTO `auth_user` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `is_staff`, `is_active`, `is_superuser`, `last_login`, `date_joined`) VALUES
(1, 'root', '', '', 'arbek_s13@hotmail.com', 'pbkdf2_sha256$10000$cB7rCzWGYk3x$fZ0lrjbH8Gmm+HcxwccYaJMlEx67EnjcFc9hU7VTdQI=', 1, 1, 1, '2012-11-15 17:59:33', '2012-11-01 18:19:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_user_groups`
--

CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_403f60f` (`user_id`),
  KEY `auth_user_groups_425ae3c4` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `auth_user_groups`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_user_user_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_403f60f` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `auth_user_user_permissions`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_admin_log`
--

CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_403f60f` (`user_id`),
  KEY `django_admin_log_1bb8f392` (`content_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Volcar la base de datos para la tabla `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `user_id`, `content_type_id`, `object_id`, `object_repr`, `action_flag`, `change_message`) VALUES
(1, '2012-11-01 19:10:25', 1, 11, '1', 'AGENDA DESDE LO LOCAL', 1, ''),
(2, '2012-11-01 19:12:49', 1, 11, '2', 'COMPROMISOS ANTE NOTARIO PUBLICO', 1, ''),
(3, '2012-11-01 19:13:32', 1, 11, '3', 'ESTRUCTURA PROGRAMÁTICA', 1, ''),
(4, '2012-11-01 19:15:41', 1, 11, '4', 'IMCO', 1, ''),
(5, '2012-11-01 19:15:57', 1, 11, '5', 'IWA4', 1, ''),
(6, '2012-11-01 19:17:52', 1, 10, '1', 'Desarrollo Humano con Responsabilidad Social', 1, ''),
(7, '2012-11-01 19:18:36', 1, 10, '2', 'Desarrollo Económico y Equidad Distributiva', 1, ''),
(8, '2012-11-01 19:19:30', 1, 10, '3', 'Desarrollo Político, Gobierno, Seguridad y Justicia', 1, ''),
(9, '2012-11-01 19:20:18', 1, 10, '4', 'Desarrollo Sustentable, Infraestructura y Servicios', 1, ''),
(10, '2012-11-01 19:22:27', 1, 10, '5', 'Desarrollo Administrativo e Innovación Gubernamental', 1, ''),
(11, '2012-11-01 19:23:32', 1, 8, '1', 'Modernización administrativa', 1, ''),
(12, '2012-11-01 19:26:39', 1, 8, '2', 'Planeación, programación y presupuestación', 1, ''),
(13, '2012-11-01 19:27:27', 1, 9, '1', 'Gobierno Electrónico', 1, ''),
(14, '2012-11-01 19:28:09', 1, 9, '2', 'Planeación, programación y presupuestación', 1, ''),
(15, '2012-11-01 19:37:39', 1, 13, '1', 'Acción', 1, ''),
(16, '2012-11-01 19:38:01', 1, 13, '2', 'Difusión/Promoción', 1, ''),
(17, '2012-11-01 19:38:18', 1, 13, '3', 'Informes/Estadistica', 1, ''),
(18, '2012-11-01 19:38:43', 1, 13, '4', 'Programa', 1, ''),
(19, '2012-11-01 19:38:59', 1, 13, '5', 'Vinculación', 1, ''),
(20, '2012-11-01 20:12:48', 1, 12, '1', 'Portal electrónico municipal', 1, ''),
(21, '2012-11-01 20:16:37', 1, 8, '3', 'Información y sistemas', 1, ''),
(22, '2012-11-01 20:16:47', 1, 9, '3', 'Transparencia y acceso a la información', 1, ''),
(23, '2012-11-01 20:17:33', 1, 12, '2', 'Índice de la calidad de la transparencia', 1, ''),
(24, '2012-11-01 21:40:49', 1, 14, '1', 'root', 1, ''),
(25, '2012-11-02 00:02:25', 1, 12, '4', 'Existencia de software', 1, ''),
(26, '2012-11-03 18:02:53', 1, 12, '1', 'Portal electrónico municipal', 1, ''),
(27, '2012-11-03 18:04:18', 1, 12, '2', 'Internet y existencia de politicas de uso ', 1, ''),
(28, '2012-11-03 18:06:02', 1, 12, '3', 'Uso sistemático de tecnología e internet', 1, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_content_type`
--

CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `name`, `app_label`, `model`) VALUES
(1, 'permission', 'auth', 'permission'),
(2, 'group', 'auth', 'group'),
(3, 'user', 'auth', 'user'),
(4, 'content type', 'contenttypes', 'contenttype'),
(5, 'session', 'sessions', 'session'),
(6, 'site', 'sites', 'site'),
(7, 'log entry', 'admin', 'logentry'),
(8, 'tema', 'estructura', 'tema'),
(9, 'subtema', 'estructura', 'subtema'),
(10, 'estructura_general', 'estructura', 'estructura_general'),
(11, 'sistema', 'estructura', 'sistema'),
(12, 'indicador', 'estructura', 'indicador'),
(13, 'categoria_indicador', 'estructura', 'categoria_indicador'),
(14, 'user profile', 'home', 'userprofile'),
(16, 'indicador568', 'indicadores', 'indicador568');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_session`
--

CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_3da3d3d8` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('9552fcc1f3445ecd8b6395bdead900b2', 'YzgzY2U2YmU1NGY5OGY4YzI2NTY5YjE2ZDBjZTA4NjFkMjhlOTY5MzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQSKAQF1Lg==\n', '2012-11-29 17:59:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_site`
--

CREATE TABLE IF NOT EXISTS `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `django_site`
--

INSERT INTO `django_site` (`id`, `domain`, `name`) VALUES
(1, 'example.com', 'example.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estructura_categoria_indicador`
--

CREATE TABLE IF NOT EXISTS `estructura_categoria_indicador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `estructura_categoria_indicador`
--

INSERT INTO `estructura_categoria_indicador` (`id`, `nombre`, `descripcion`, `status`) VALUES
(1, 'Acción', 'Acción', 1),
(2, 'Difusión/Promoción', 'Difusión/Promoción', 1),
(3, 'Informes/Estadistica', 'Informes/Estadistica', 1),
(4, 'Programa', 'Programa', 1),
(5, 'Vinculación', 'Vinculación', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estructura_estructura_general`
--

CREATE TABLE IF NOT EXISTS `estructura_estructura_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(2) NOT NULL,
  `designacion` varchar(10) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` longtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `estructura_estructura_general`
--

INSERT INTO `estructura_estructura_general` (`id`, `clave`, `designacion`, `nombre`, `descripcion`, `status`) VALUES
(1, '01', 'Pilar 1', 'Desarrollo Humano con Responsabilidad Social', 'Desarrollo Humano con Responsabilidad Social', 1),
(2, '02', 'Pilar 2', 'Desarrollo Económico y Equidad Distributiva', 'Desarrollo Económico y Equidad Distributiva', 1),
(3, '03', 'Pilar 3', 'Desarrollo Político, Gobierno, Seguridad y Justicia', 'Desarrollo Político, Gobierno, Seguridad y Justicia', 1),
(4, '04', 'Pilar 4', 'Desarrollo Sustentable, Infraestructura y Servicios', 'Desarrollo Sustentable, Infraestructura y Servicios', 1),
(5, '05', 'Eje', 'Desarrollo Administrativo e Innovación Gubernamental', 'Desarrollo Administrativo e Innovación Gubernamental', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estructura_indicador`
--

CREATE TABLE IF NOT EXISTS `estructura_indicador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(3) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` longtext NOT NULL,
  `formula` longtext NOT NULL,
  `fecha` date NOT NULL,
  `indicador` decimal(2,2) NOT NULL,
  `estructura_id` int(11) NOT NULL,
  `tema_id` int(11) NOT NULL,
  `subtema_id` int(11) NOT NULL,
  `sistema_id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `estructura_indicador_643c5166` (`estructura_id`),
  KEY `estructura_indicador_e189947` (`tema_id`),
  KEY `estructura_indicador_2caa03d6` (`subtema_id`),
  KEY `estructura_indicador_59eb0d17` (`sistema_id`),
  KEY `estructura_indicador_64c3c188` (`categoria_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `estructura_indicador`
--

INSERT INTO `estructura_indicador` (`id`, `clave`, `nombre`, `descripcion`, `formula`, `fecha`, `indicador`, `estructura_id`, `tema_id`, `subtema_id`, `sistema_id`, `categoria_id`) VALUES
(1, '652', 'Portal electrónico municipal', 'Portal electrónico municipal', 'var1+var2/var3', '2012-11-03', 0.12, 5, 1, 1, 1, 1),
(2, '656', 'Internet y existencia de politicas de uso ', 'Internet y existencia de politicas de uso ', 'var1+var2', '2012-11-13', 0.30, 5, 1, 1, 1, 1),
(3, '658', 'Uso sistemático de tecnología e internet', 'Uso sistemático de tecnología e internet', 'var1*100', '2012-11-20', 0.56, 5, 1, 1, 5, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estructura_sistema`
--

CREATE TABLE IF NOT EXISTS `estructura_sistema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(2) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` longtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `estructura_sistema`
--

INSERT INTO `estructura_sistema` (`id`, `clave`, `nombre`, `descripcion`, `status`) VALUES
(1, '01', 'AGENDA DESDE LO LOCAL', 'AGENDA DESDE LO LOCAL', 1),
(2, '02', 'COMPROMISOS ANTE NOTARIO PUBLICO', 'COMPROMISOS ANTE NOTARIO PUBLICO', 1),
(3, '03', 'ESTRUCTURA PROGRAMÁTICA', 'ESTRUCTURA PROGRÁMATICA', 1),
(4, '04', 'IMCO', 'Un centro de investigación aplicada independiente, a-partidista y sin fines de lucro.\r\n\r\nEstudiamos fenómenos económicos y sociales que afectan la competitividad en el contexto de una economía globalizada', 1),
(5, '05', 'IWA4', 'Los documentos IWA (International Workshop Agreement) proporcionan lineamientos para la aplicación de normas en sectores específicos. Estos lineamientos no agregan, cambian o modifican los requisitos de las normas, y la intención de su uso no es para efectos de evaluación de cumplimento contractual o para la certificación, sino de la mejor utilización de las normas.', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estructura_subtema`
--

CREATE TABLE IF NOT EXISTS `estructura_subtema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `descripcion` longtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `estructura_subtema`
--

INSERT INTO `estructura_subtema` (`id`, `nombre`, `descripcion`, `status`) VALUES
(1, 'Gobierno Electrónico', 'Gobierno Electrónico', 1),
(2, 'Planeación, programación y presupuestación', 'Planeación, programación y presupuestación', 1),
(3, 'Transparencia y acceso a la información', 'Transparencia y acceso a la información', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estructura_tema`
--

CREATE TABLE IF NOT EXISTS `estructura_tema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(2) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` longtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `estructura_tema`
--

INSERT INTO `estructura_tema` (`id`, `clave`, `nombre`, `descripcion`, `status`) VALUES
(1, '32', 'Modernización administrativa', 'Modernización administrativa', 1),
(2, '38', 'Planeación, programación y presupuestación', 'Planeación, programación y presupuestación', 1),
(3, '52', 'Información y sistemas', 'Información y sistemas', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `home_userprofile`
--

CREATE TABLE IF NOT EXISTS `home_userprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `area` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `home_userprofile`
--

INSERT INTO `home_userprofile` (`id`, `user_id`, `photo`, `area`) VALUES
(1, 1, 'MultimediaData/Users/root/admin.jpg', 'Desarrollo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `indicadores_indicador652`
--

CREATE TABLE IF NOT EXISTS `indicadores_indicador652` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicador_id` int(11) NOT NULL,
  `variable1` int(11) NOT NULL,
  `variable2` int(11) NOT NULL,
  `variable3` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `indicadores_indicador652_8ec0fe6` (`indicador_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `indicadores_indicador652`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `indicadores_indicador656`
--

CREATE TABLE IF NOT EXISTS `indicadores_indicador656` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicador_id` int(11) NOT NULL,
  `variable1` int(11) NOT NULL,
  `variable2` int(11) NOT NULL,
  `variable3` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `indicadores_indicador656_8ec0fe6` (`indicador_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `indicadores_indicador656`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `indicadores_indicador658`
--

CREATE TABLE IF NOT EXISTS `indicadores_indicador658` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicador_id` int(11) NOT NULL,
  `variable1` int(11) NOT NULL,
  `variable2` int(11) NOT NULL,
  `variable3` int(11) NOT NULL,
  `variable4` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `indicadores_indicador658_8ec0fe6` (`indicador_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `indicadores_indicador658`
--


--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `group_id_refs_id_3cea63fe` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `permission_id_refs_id_5886d21f` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Filtros para la tabla `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `content_type_id_refs_id_728de91f` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Filtros para la tabla `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `group_id_refs_id_f116770` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `user_id_refs_id_7ceef80f` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Filtros para la tabla `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `permission_id_refs_id_67e79cb` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `user_id_refs_id_dfbab7d` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Filtros para la tabla `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `content_type_id_refs_id_288599e6` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `user_id_refs_id_c8665aa` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Filtros para la tabla `estructura_indicador`
--
ALTER TABLE `estructura_indicador`
  ADD CONSTRAINT `categoria_id_refs_id_3fec86f1` FOREIGN KEY (`categoria_id`) REFERENCES `estructura_categoria_indicador` (`id`),
  ADD CONSTRAINT `estructura_id_refs_id_5999ce58` FOREIGN KEY (`estructura_id`) REFERENCES `estructura_estructura_general` (`id`),
  ADD CONSTRAINT `sistema_id_refs_id_1c972cac` FOREIGN KEY (`sistema_id`) REFERENCES `estructura_sistema` (`id`),
  ADD CONSTRAINT `subtema_id_refs_id_104094c7` FOREIGN KEY (`subtema_id`) REFERENCES `estructura_subtema` (`id`),
  ADD CONSTRAINT `tema_id_refs_id_49db868` FOREIGN KEY (`tema_id`) REFERENCES `estructura_tema` (`id`);

--
-- Filtros para la tabla `home_userprofile`
--
ALTER TABLE `home_userprofile`
  ADD CONSTRAINT `user_id_refs_id_3586036c` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Filtros para la tabla `indicadores_indicador652`
--
ALTER TABLE `indicadores_indicador652`
  ADD CONSTRAINT `indicador_id_refs_id_1cc94203` FOREIGN KEY (`indicador_id`) REFERENCES `estructura_indicador` (`id`);

--
-- Filtros para la tabla `indicadores_indicador656`
--
ALTER TABLE `indicadores_indicador656`
  ADD CONSTRAINT `indicador_id_refs_id_335daa59` FOREIGN KEY (`indicador_id`) REFERENCES `estructura_indicador` (`id`);

--
-- Filtros para la tabla `indicadores_indicador658`
--
ALTER TABLE `indicadores_indicador658`
  ADD CONSTRAINT `indicador_id_refs_id_4b422087` FOREIGN KEY (`indicador_id`) REFERENCES `estructura_indicador` (`id`);
